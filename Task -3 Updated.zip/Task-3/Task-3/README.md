# Task-3
Kaiburr assignment
To Run in docker.
Open terminal
Go to Server/target
And run docker build . -t server
This will create a image of the JAR file.
Now run the docker-compose.yml using docker-compose up.
Now using web Browser at localhost:8086 we can use the endpoints.
